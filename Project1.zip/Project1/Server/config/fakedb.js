exports.users = [
    {
        _id: "23131",
        firstName: "Mukesh",
        lastName: "Kumar",
        email: "mukesh@gmail.com",
        password: "123456",
    },
    {
        _id: "23132",
        firstName: "Riya",
        lastName: "Sharma",
        email: "riya@gmail.com",
        password: "riya@123",
    },
    {
        _id: "23133",
        firstName: "Aman",
        lastName: "Verma",
        email: "aman@gmail.com",
        password: "aman@123",
    },
    {
        _id: "23134",
        firstName: "Sneha",
        lastName: "Patel",
        email: "sneha@gmail.com",
        password: "sneha@123",
    },
    {
        _id: "23135",
        firstName: "Rahul",
        lastName: "Singh",
        email: "rahul@gmail.com",
        password: "rahul@123",
    }
];

exports.quotes = [
    {
        quote: "I turn coffee into code",
        by: "23131",
    },
    {
        quote: "I have another quote",
        by: "23131",
    },
    {
        quote: "Code is like humor. When you have to explain it, it’s bad",
        by: "23132",
    },
    {
        quote: "First, solve the problem. Then, write the code",
        by: "23133",
    },
    {
        quote: "Experience is the name everyone gives to their mistakes",
        by: "23134",
    },
    {
        quote: "Simplicity is the soul of efficiency",
        by: "23135",
    }
];
