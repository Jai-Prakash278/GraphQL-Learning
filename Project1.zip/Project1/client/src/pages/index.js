export { default as Home } from "./Home";
export { default as Login } from "./Login";
export { default as SignUp } from "./SignUp";
export { default as CreateQuote } from "./CreateQuote";
export { default as Profile } from "./Profile";
