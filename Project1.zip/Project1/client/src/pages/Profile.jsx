import { useQuery } from "@apollo/client/react";
import { GET_MY_PROFILE } from "../gqlOperations/queries";
import { useNavigate } from "react-router-dom";

export default function Profile() {
  const { loading, error, data } = useQuery(GET_MY_PROFILE);
  const navigate = useNavigate();
  if (loading) return <h2>Profile is loading...</h2>;
  const token = localStorage.getItem("token");
  if (!token) {
    navigate("/login");
    return <h1>Unauthorized</h1>;
  }
  if (error) {
    console.log(error);
  }
  return (
    <div className="py-8 animate-fadeIn">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* User Profile Card - Vertical Layout */}
        <div className="bg-white rounded-lg shadow-lg p-8 mb-8 transform hover:scale-[1.02] transition-all duration-300 animate-slideDown">
          <div className="flex flex-col items-center text-center">
            <img
              src={`https://robohash.org/${data.user.firstName}.png`}
              alt="User avatar"
              className="w-32 h-32 rounded-full border-4 border-purple-500 shadow-xl mb-4 hover:rotate-6 transition-transform duration-300"
            />
            <h5 className="text-3xl font-bold text-gray-800 mb-2">
              {" "}
              {data.user.firstName} {data.user.lastName}{" "}
            </h5>
            <h5 className="text-gray-600"> Email - {data.user.email} </h5>
          </div>
        </div>

        {/* Quotes Section */}
        <div>
          <h3 className="text-3xl font-bold text-gray-800 mb-6 animate-slideRight">
            Quotes
          </h3>
          <div className="space-y-4">
            {data.user.quotes.map((quote) => {
              return (
                <blockquote className="bg-white rounded-lg shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 animate-slideUp">
                  <div className="flex items-start p-6 border-l-4 border-purple-500">
                    <div className="flex-1">
                      <h6 className="text-gray-800 text-lg leading-relaxed mb-3">
                        {quote.quote}
                      </h6>
                      <p className="text-gray-600 italic text-sm">- Name</p>
                    </div>
                  </div>
                </blockquote>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
